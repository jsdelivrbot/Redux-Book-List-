export default function BookReducer (){
  return[
    {title: 'Book 1', pages: 100},
    {title: 'Book 2', pages: 200},
    {title: 'Book 3', pages: 300},
    {title: 'Book 4', pages: 400}
  ]
}